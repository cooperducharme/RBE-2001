#include <Arduino.h>
#include "chassis.h"
#include "rangefinder.h"

#define trigPin 12
#define echoPin 0

void isr_t();

Chassis robot;
Rangefinder us;
Romi32U4ButtonA buttonA;
Romi32U4ButtonB buttonB;
Romi32U4ButtonC buttonC;

int state = 0;

void setup() {
	us.setup(trigPin, echoPin);
	attachInterrupt(digitalPinToInterrupt(echoPin), isr_t, CHANGE);
	Serial.begin(9600);
	us.updateDistance();
	delay(5);
}

void loop() {
	us.loop();
	if(us.getDistanceCM() < 20) {
		robot.turnAngle(180);
		us.updateDistance(); // Force the sensor to update (we know at least some time has passed)
		delay(5);
	}

	robot.drive(100);
}

void isr_t() {
	us.isr();
}